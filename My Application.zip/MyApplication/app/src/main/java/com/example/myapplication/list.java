package com.example.myapplication;

public class list {
    private String lists;

    public list(String lists){
        this.lists = lists;
    }
    public String getLists(){
        return lists;
    }
    public void setLists(String lists){
        this.lists = lists;
    }
}
